# Task Manager PC-style (Android)

App Task Manager cho điện thoại, giao diện lấy cảm hứng từ Task Manager trên Windows
(nền tối, 3 tab: Processes / Performance / Startup), viết bằng Kotlin + Jetpack Compose.

## Cách build ra file APK

1. Cài **Android Studio** (bản mới nhất): https://developer.android.com/studio
2. Mở Android Studio → **Open** → chọn thư mục `TaskManagerPC` (thư mục chứa file `settings.gradle.kts`)
3. Đợi Gradle sync xong (lần đầu sẽ tải Gradle + SDK, cần mạng)
4. Vào menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. File APK debug sẽ nằm ở: `app/build/outputs/apk/debug/app-debug.apk`
6. Cắm điện thoại qua USB (bật **Chế độ nhà phát triển** + **Gỡ lỗi USB**) rồi bấm nút Run (▶) để cài thẳng lên máy, hoặc copy file APK qua điện thoại rồi cài thủ công.

## Cấu trúc project

```
TaskManagerPC/
├── app/
│   ├── build.gradle.kts          # cấu hình module app, thư viện dùng
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/taskmanager/
│       │   ├── MainActivity.kt   # toàn bộ UI + logic (3 tab)
│       │   └── ui/theme/         # màu sắc, theme dark giống PC
│       └── res/                  # icon, string, theme XML
├── build.gradle.kts
└── settings.gradle.kts
```

## 3 tab hiện có

- **Processes**: mặc định chỉ hiện **app đang chạy** + cột **Memory (PSS)** cập nhật mỗi 2s
  (giống Windows Task Manager). Có thể bật “Tất cả app đã cài”, hiện app hệ thống, sắp xếp
  theo Memory / Thời gian dùng / Dung lượng. Nút “Kết thúc”.
- **Performance**: CPU, RAM, **Ổ đĩa (đường dẫn chuẩn /data + StorageManager)**, **GPU**
  (sysfs Adreno/Mali nếu máy cho phép), Mạng (tốc độ real-time + tổng traffic từ lúc bật máy),
  Pin. Đồ thị real-time cho RAM & CPU. Fallback %CPU từ tần số nhân khi `/proc/stat` bị chặn.
- **Startup**: app có `BOOT_COMPLETED`, bấm để mở Cài đặt tắt tự khởi động.

## Giới hạn quan trọng (do chính sách bảo mật Android, không phải do code)

- **Memory từng app**: Android 7+/10+ hạn chế `getRunningAppProcesses` — app thường thường
  chỉ thấy process của chính nó hoặc rất ít process. App đã cảnh báo trên UI khi danh sách
  quá ngắn. Muốn xem đầy đủ cần root / app hệ thống.
- **GPU**: đọc sysfs (kgsl/devfreq). Nhiều máy chặn → chỉ hiện tên chip hoặc “Không đọc được”.
- Từ Android 8.0, SELinux chặn `/proc/stat` → fallback ước tính %CPU từ tần số nhân.
- Từ Android 10+, nhiều máy chặn `/proc/diskstats` → không có tốc độ đọc/ghi đĩa real-time
  (dung lượng ổ vẫn đọc được qua StorageManager/StatFs).
- Không Force Stop app khác bằng code — chỉ mở màn Cài đặt.

## Gợi ý khi đưa qua ChatGPT/Grok chỉnh giao diện

- File cần đưa: `MainActivity.kt` (toàn bộ UI) và `ui/theme/Color.kt`, `Theme.kt` (bảng màu).
- Có thể yêu cầu AI thêm: animation chuyển tab, thêm tab "Details"/"Services" giả lập,
  làm đồ thị Performance đẹp hơn (nhiều màu, gradient), thêm dark/light switch, splash screen, icon đẹp hơn.
