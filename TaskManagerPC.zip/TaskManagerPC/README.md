# Task Manager PC-style (Android)

App Task Manager cho điện thoại, giao diện lấy cảm hứng từ Task Manager trên Windows
(nền tối, 3 tab: Processes / Performance / Startup), viết bằng Kotlin + Jetpack Compose.

## Cách build ra file APK

1. Cài **Android Studio** (bản mới nhất): https://developer.android.com/studio
2. Mở Android Studio → **Open** → chọn thư mục `TaskManagerPC` (thư mục chứa file `settings.gradle.kts`)
3. Đợi Gradle sync xong (lần đầu sẽ tải Gradle + SDK, cần mạng)
4. Vào menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. File APK debug sẽ nằm ở: `app/build/outputs/apk/debug/app-debug.apk`
6. Cắm điện thoại qua USB (bật **Chế độ nhà phát triển** + **Gỡ lỗi USB**) rồi bấm nút Run (▶) để cài thẳng lên máy, hoặc copy file APK qua điện thoại rồi cài thủ công.

## Cấu trúc project

```
TaskManagerPC/
├── app/
│   ├── build.gradle.kts          # cấu hình module app, thư viện dùng
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/taskmanager/
│       │   ├── MainActivity.kt   # toàn bộ UI + logic (3 tab)
│       │   └── ui/theme/         # màu sắc, theme dark giống PC
│       └── res/                  # icon, string, theme XML
├── build.gradle.kts
└── settings.gradle.kts
```

## 3 tab hiện có

- **Processes**: liệt kê app đã cài (icon, tên, package, dung lượng file cài đặt),
  nút "Kết thúc" mở màn hình Cài đặt của app đó để Force Stop/Gỡ (Android không cho
  app thường tắt trực tiếp app khác).
- **Performance**: RAM, bộ nhớ trong, pin, số nhân CPU — **số liệu thật 100%** lấy
  từ hệ thống Android, có đồ thị real-time cho RAM.
- **Startup**: liệt kê các app có đăng ký nhận sự kiện khởi động máy (`BOOT_COMPLETED`),
  bấm vào để mở Cài đặt và tắt quyền tự khởi động thủ công.

## Giới hạn quan trọng (do chính sách bảo mật Android, không phải do code)

- Từ Android 5.0 trở đi, **một app thường không thể xem % CPU/RAM đang dùng của app khác**
  (khác với Windows). Vì vậy phần "Processes" hiển thị dung lượng cài đặt (APK size) thay
  vì CPU/RAM real-time của từng app — đây là giới hạn hệ điều hành, không sửa được trừ khi máy đã root.
- Không thể tự động Force Stop app khác bằng code — chỉ mở được màn hình Cài đặt để người
  dùng tự bấm.
- Cần cấp quyền thủ công một số trường hợp (ví dụ Android 11+ có thể cần bật
  "Cho phép truy cập tất cả ứng dụng" nếu Google Play Console giới hạn).

## Gợi ý khi đưa qua ChatGPT/Grok chỉnh giao diện

- File cần đưa: `MainActivity.kt` (toàn bộ UI) và `ui/theme/Color.kt`, `Theme.kt` (bảng màu).
- Có thể yêu cầu AI thêm: animation chuyển tab, thêm tab "Details"/"Services" giả lập,
  làm đồ thị Performance đẹp hơn (nhiều màu, gradient), thêm dark/light switch, splash screen, icon đẹp hơn.
