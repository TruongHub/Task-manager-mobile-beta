package com.example.taskmanager.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TaskManagerColorScheme = darkColorScheme(
    primary = AccentTeal,
    secondary = AccentBlue,
    background = BgDark,
    surface = BgPanel,
    onPrimary = Color.Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
)

@Composable
fun TaskManagerPCTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = TaskManagerColorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
