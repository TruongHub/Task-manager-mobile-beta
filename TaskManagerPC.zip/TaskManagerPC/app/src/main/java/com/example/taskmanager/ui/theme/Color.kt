package com.example.taskmanager.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF1E1E1E)
val BgPanel = Color(0xFF252526)
val BgRowAlt = Color(0xFF2A2D2E)
val BgHeader = Color(0xFF2D2D30)
val AccentTeal = Color(0xFF00D9E8)
val AccentTealDim = Color(0xFF00838F)
val AccentBlue = Color(0xFF0078D4)
val TextPrimary = Color(0xFFF1F1F1)
val TextSecondary = Color(0xFFA0A0A0)
val BorderColor = Color(0xFF3F3F3F)
val GraphGreen = Color(0xFF6BCB3D)
val WarnOrange = Color(0xFFFFA733)
val DangerRed = Color(0xFFE81123)

// Màu riêng cho từng thẻ ở tab Performance, giống bảng màu của Windows Task Manager
// (CPU xanh dương, RAM tím, Ổ đĩa vàng/cam, Mạng xanh lá, Pin xanh ngọc)
val PerfCpuBlue = Color(0xFF0078D4)
val PerfRamPurple = Color(0xFF9B59D0)
val PerfDiskYellow = Color(0xFFE8C547)
val PerfNetworkGreen = Color(0xFF6BCB3D)
val PerfBatteryTeal = Color(0xFF00D9E8)
