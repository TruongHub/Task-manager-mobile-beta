package com.example.taskmanager

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.StatFs
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.taskmanager.ui.theme.*
import kotlinx.coroutines.delay
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TaskManagerPCTheme {
                TaskManagerApp()
            }
        }
    }
}

data class AppEntry(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable,
    val sizeMb: Double,
    val isSystemApp: Boolean,
    val foregroundMinutesToday: Double = 0.0, // thời gian dùng thật hôm nay, từ UsageStatsManager
    val lastUsedMs: Long = 0L
)

// Kiểm tra xem người dùng đã cấp quyền "Usage Access" chưa (cần bật thủ công trong Settings)
fun hasUsageAccessPermission(context: Context): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = appOps.checkOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS,
        Process.myUid(),
        context.packageName
    )
    return mode == AppOpsManager.MODE_ALLOWED
}

// Lấy thời gian sử dụng THẬT của từng app trong ngày hôm nay, dùng UsageStatsManager
fun loadUsageStatsToday(context: Context): Map<String, Double> {
    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val end = System.currentTimeMillis()
    val start = end - (24L * 60 * 60 * 1000) // 24 giờ gần nhất
    val statsList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
    val result = mutableMapOf<String, Double>()
    statsList?.forEach { stat ->
        val minutes = stat.totalTimeInForeground / 60000.0
        if (minutes > 0) {
            // Nếu app xuất hiện nhiều lần (nhiều interval), cộng dồn
            result[stat.packageName] = (result[stat.packageName] ?: 0.0) + minutes
        }
    }
    return result
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskManagerApp() {
    val tabs = listOf(
        Triple("Processes", Icons.Default.List, "Ứng dụng"),
        Triple("Performance", Icons.Default.Speed, "Hiệu năng"),
        Triple("Startup", Icons.Default.PowerSettingsNew, "Khởi động")
    )
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            Column(
                modifier = Modifier.background(
                    Brush.verticalGradient(listOf(BgHeader, BgHeader.copy(alpha = 0.96f)))
                )
            ) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Memory,
                                contentDescription = null,
                                tint = AccentTeal,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Task Manager",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        titleContentColor = TextPrimary
                    )
                )
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = AccentTeal,
                    indicator = { positions ->
                        if (selectedTab < positions.size) {
                            Box(
                                modifier = Modifier
                                    .tabIndicatorOffset(positions[selectedTab])
                                    .height(3.dp)
                                    .padding(horizontal = 24.dp)
                                    .background(
                                        Brush.horizontalGradient(listOf(AccentTealDim, AccentTeal)),
                                        RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)
                                    )
                            )
                        }
                    },
                    divider = { HorizontalDivider(color = BorderColor, thickness = 1.dp) }
                ) {
                    tabs.forEachIndexed { index, (title, icon, _) ->
                        val selected = selectedTab == index
                        Tab(
                            selected = selected,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    title,
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) AccentTeal else TextSecondary
                                )
                            },
                            icon = {
                                Icon(
                                    icon,
                                    contentDescription = null,
                                    tint = if (selected) AccentTeal else TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BgDark)
                .padding(padding)
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally(animationSpec = tween(280)) { w -> dir * w / 4 } +
                            fadeIn(animationSpec = tween(280))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(280)) { w -> -dir * w / 4 } +
                                    fadeOut(animationSpec = tween(280)))
                },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    0 -> ProcessesScreen()
                    1 -> PerformanceScreen()
                    2 -> StartupScreen()
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------
// TAB 1: PROCESSES
// ---------------------------------------------------------------------------------

@Composable
fun ProcessesScreen() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var showSystemApps by remember { mutableStateOf(false) }
    var hasUsagePermission by remember { mutableStateOf(hasUsageAccessPermission(context)) }
    var sortByUsage by remember { mutableStateOf(false) }

    // Kiểm tra lại quyền mỗi khi quay lại màn hình (sau khi bật trong Settings)
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                hasUsagePermission = hasUsageAccessPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(hasUsagePermission) {
        val usageMap = if (hasUsagePermission) loadUsageStatsToday(context) else emptyMap()
        apps = loadInstalledApps(context, usageMap)
        loading = false
    }

    val filtered = remember(apps, showSystemApps, sortByUsage) {
        val base = if (showSystemApps) apps else apps.filter { !it.isSystemApp }
        if (sortByUsage) base.sortedByDescending { it.foregroundMinutesToday }
        else base.sortedByDescending { it.sizeMb }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (!hasUsagePermission) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(WarnOrange.copy(alpha = 0.18f), WarnOrange.copy(alpha = 0.06f))
                        ),
                        RoundedCornerShape(10.dp)
                    )
                    .border(1.dp, WarnOrange.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = WarnOrange)
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Cần cấp quyền để xem thời gian dùng THẬT của từng app",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        "Bấm để mở Cài đặt → tìm \"Task Manager\" → bật Usage Access",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                TextButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }) {
                    Text("Mở Cài đặt", color = AccentTeal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Header giống bảng cột trên Windows Task Manager
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgHeader)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(
                "Tên",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                if (hasUsagePermission) "Dùng hôm nay" else "Dung lượng",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.width(90.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
            Spacer(modifier = Modifier.width(70.dp))
        }
        HorizontalDivider(color = BorderColor, thickness = 1.dp)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = showSystemApps,
                onCheckedChange = { showSystemApps = it },
                colors = CheckboxDefaults.colors(checkedColor = AccentTeal)
            )
            Text("Hiện cả app hệ thống", color = TextSecondary, fontSize = 13.sp)
            Spacer(modifier = Modifier.weight(1f))
            if (hasUsagePermission) {
                TextButton(onClick = { sortByUsage = !sortByUsage }) {
                    Text(
                        if (sortByUsage) "Đang sắp: Thời gian dùng" else "Đang sắp: Dung lượng",
                        color = AccentTeal,
                        fontSize = 11.sp
                    )
                }
            }
            Text("${filtered.size} tiến trình", color = TextSecondary, fontSize = 12.sp)
        }

        if (loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentTeal)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filtered) { app ->
                    ProcessRow(app, context, hasUsagePermission)
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }
    }
}

@Composable
fun ProcessRow(app: AppEntry, context: Context, hasUsagePermission: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .background(BgPanel.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val bitmap = remember(app.packageName) { app.icon.toBitmapSafe() }
        if (bitmap != null) {
            androidx.compose.foundation.Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(BgDark, RoundedCornerShape(8.dp))
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                app.name,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                app.packageName,
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        val valueText = if (hasUsagePermission) {
            if (app.foregroundMinutesToday >= 60)
                "%.1f giờ".format(app.foregroundMinutesToday / 60.0)
            else
                "%.0f phút".format(app.foregroundMinutesToday)
        } else {
            "%.1f MB".format(app.sizeMb)
        }
        Text(
            valueText,
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.width(90.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
        TextButton(
            onClick = {
                // Thử tắt tiến trình nền THẬT trước (chỉ có tác dụng nếu app đang chạy nền)
                val killed = killAppBackgroundProcess(context, app.packageName)
                if (killed) {
                    Toast.makeText(
                        context,
                        "Đã gửi lệnh tắt tiến trình nền của ${app.name}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                // Vẫn mở thêm màn Cài đặt để người dùng tự Force Stop nếu app đang mở trên màn hình
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.parse("package:${app.packageName}")
                context.startActivity(intent)
            },
            modifier = Modifier.width(70.dp),
            colors = ButtonDefaults.textButtonColors(contentColor = DangerRed)
        ) {
            Text("Kết thúc", color = DangerRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

fun android.graphics.drawable.Drawable.toBitmapSafe(): android.graphics.Bitmap? {
    return try {
        val bmp = android.graphics.Bitmap.createBitmap(
            intrinsicWidth.coerceAtLeast(1),
            intrinsicHeight.coerceAtLeast(1),
            android.graphics.Bitmap.Config.ARGB_8888
        )
        val canvas = android.graphics.Canvas(bmp)
        setBounds(0, 0, canvas.width, canvas.height)
        draw(canvas)
        bmp
    } catch (e: Exception) {
        null
    }
}

fun loadInstalledApps(context: Context, usageMap: Map<String, Double> = emptyMap()): List<AppEntry> {
    val pm = context.packageManager
    val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
    return packages.mapNotNull { appInfo ->
        try {
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val sourceFile = File(appInfo.sourceDir)
            val sizeMb = sourceFile.length() / (1024.0 * 1024.0)
            AppEntry(
                name = pm.getApplicationLabel(appInfo).toString(),
                packageName = appInfo.packageName,
                icon = pm.getApplicationIcon(appInfo),
                sizeMb = sizeMb,
                isSystemApp = isSystem,
                foregroundMinutesToday = usageMap[appInfo.packageName] ?: 0.0
            )
        } catch (e: Exception) {
            null
        }
    }
}

// Thử tắt tiến trình nền THẬT của 1 app (chỉ tắt được app đang chạy NỀN,
// không tắt được app đang mở trên màn hình — đây là giới hạn của Android, không phải lỗi code)
fun killAppBackgroundProcess(context: Context, packageName: String): Boolean {
    return try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.killBackgroundProcesses(packageName)
        true
    } catch (e: Exception) {
        false
    }
}

// ---------------------------------------------------------------------------------
// TAB 2: PERFORMANCE
// ---------------------------------------------------------------------------------

@Composable
fun PerformanceScreen() {
    val context = LocalContext.current
    var ramUsedPercent by remember { mutableStateOf(0f) }
    var ramUsedGb by remember { mutableStateOf(0.0) }
    var ramTotalGb by remember { mutableStateOf(0.0) }
    var storageUsedPercent by remember { mutableStateOf(0f) }
    var storageUsedGb by remember { mutableStateOf(0.0) }
    var storageTotalGb by remember { mutableStateOf(0.0) }
    var batteryPercent by remember { mutableStateOf(0) }
    var isCharging by remember { mutableStateOf(false) }
    val cpuCores = remember { Runtime.getRuntime().availableProcessors() }

    val ramHistory = remember { mutableStateListOf<Float>() }
    val cpuHardware = remember { readCpuHardwareInfo() }
    var cpuCoreInfo by remember { mutableStateOf<List<CpuCoreInfo>>(emptyList()) }
    var cpuReadBlocked by remember { mutableStateOf(false) }

    // CPU % tổng thể (giống thanh CPU trên Windows Task Manager)
    val cpuUsageHistory = remember { mutableStateListOf<Float>() }
    var cpuUsagePercent by remember { mutableStateOf(0f) }
    var cpuUsageBlocked by remember { mutableStateOf(false) }

    // Tốc độ mạng thật
    var downloadKBs by remember { mutableStateOf(0.0) }
    var uploadKBs by remember { mutableStateOf(0.0) }
    val downloadHistory = remember { mutableStateListOf<Float>() }
    var networkUnsupported by remember { mutableStateOf(false) }

    // Tốc độ đĩa thật
    var diskReadKBs by remember { mutableStateOf(0.0) }
    var diskWriteKBs by remember { mutableStateOf(0.0) }
    var diskReadBlocked by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        var prevCpuSnap = readCpuStatSnapshot()
        var prevNetSnap = readNetworkSnapshot()
        var prevDiskSnap = readDiskSnapshot()
        diskReadBlocked = prevDiskSnap == null

        while (true) {
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val used = memInfo.totalMem - memInfo.availMem
            ramUsedPercent = used.toFloat() / memInfo.totalMem.toFloat()
            ramUsedGb = used / (1024.0 * 1024.0 * 1024.0)
            ramTotalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)

            val stat = StatFs(context.filesDir.path)
            val totalBytes = stat.totalBytes
            val availBytes = stat.availableBytes
            val usedBytes = totalBytes - availBytes
            storageUsedPercent = usedBytes.toFloat() / totalBytes.toFloat()
            storageUsedGb = usedBytes / (1024.0 * 1024.0 * 1024.0)
            storageTotalGb = totalBytes / (1024.0 * 1024.0 * 1024.0)

            batteryPercent = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            isCharging = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ==
                    BatteryManager.BATTERY_STATUS_CHARGING

            ramHistory.add(ramUsedPercent)
            if (ramHistory.size > 40) ramHistory.removeAt(0)

            val freqs = readCpuCoreFrequencies(cpuCores)
            cpuCoreInfo = freqs
            cpuReadBlocked = freqs.all { it.currentMhz == null }

            // CPU % tổng thể
            val currCpuSnap = readCpuStatSnapshot()
            if (prevCpuSnap != null && currCpuSnap != null) {
                val pct = calcCpuUsagePercent(prevCpuSnap, currCpuSnap)
                if (pct != null) {
                    cpuUsagePercent = pct
                    cpuUsageHistory.add(pct)
                    if (cpuUsageHistory.size > 40) cpuUsageHistory.removeAt(0)
                    cpuUsageBlocked = false
                } else {
                    cpuUsageBlocked = true
                }
            } else {
                cpuUsageBlocked = true
            }
            prevCpuSnap = currCpuSnap

            // Tốc độ mạng
            val currNetSnap = readNetworkSnapshot()
            val (down, up) = calcNetworkSpeedKBs(prevNetSnap, currNetSnap)
            if (down < 0) {
                networkUnsupported = true
            } else {
                downloadKBs = down
                uploadKBs = up
                downloadHistory.add((down / 512.0).coerceIn(0.0, 1.0).toFloat()) // chuẩn hoá thô cho đồ thị
                if (downloadHistory.size > 40) downloadHistory.removeAt(0)
            }
            prevNetSnap = currNetSnap

            // Tốc độ đĩa
            val currDiskSnap = readDiskSnapshot()
            if (prevDiskSnap != null && currDiskSnap != null) {
                val (r, w) = calcDiskSpeedKBs(prevDiskSnap, currDiskSnap)
                diskReadKBs = r
                diskWriteKBs = w
                diskReadBlocked = false
            } else {
                diskReadBlocked = true
            }
            prevDiskSnap = currDiskSnap

            delay(1000)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        item {
            PerfCard(
                title = "CPU",
                subtitle = if (cpuUsageBlocked) "$cpuCores nhân" else "${(cpuUsagePercent * 100).toInt()}% · $cpuCores nhân",
                percent = if (cpuUsageBlocked) null else cpuUsagePercent,
                graphValues = if (cpuUsageBlocked) null else cpuUsageHistory,
                icon = Icons.Default.Memory
            ) {
                Text(
                    "Chip: ${cpuHardware.hardware ?: "Không xác định"}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Text(
                    "Board: ${cpuHardware.processor ?: "N/A"}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Text(
                    "Kiến trúc: ${cpuHardware.abi}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                if (cpuUsageBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Không đọc được %CPU tổng (máy chặn /proc/stat).",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                }

                if (cpuReadBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Máy này chặn đọc tần số CPU chi tiết (giới hạn từ nhà sản xuất/Android 8+), " +
                                "giống nhiều app CPU-Z gặp trên một số dòng máy.",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                } else if (cpuCoreInfo.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Tần số từng nhân (real-time)",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    cpuCoreInfo.forEach { core -> CpuCoreBar(core) }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Bộ nhớ (RAM)",
                subtitle = "%.1f/%.1f GB (%d%%)".format(ramUsedGb, ramTotalGb, (ramUsedPercent * 100).toInt()),
                percent = ramUsedPercent,
                graphValues = ramHistory,
                icon = Icons.Default.Storage
            )
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Ổ đĩa (Storage)",
                subtitle = "%.1f/%.1f GB (%d%%)".format(storageUsedGb, storageTotalGb, (storageUsedPercent * 100).toInt()),
                percent = storageUsedPercent,
                graphValues = null,
                icon = Icons.Default.Save
            ) {
                if (diskReadBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Máy này chặn đọc tốc độ đọc/ghi đĩa real-time (/proc/diskstats bị giới hạn từ Android 10+).",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("↓ Đọc: %.0f KB/s".format(diskReadKBs), color = TextSecondary, fontSize = 12.sp)
                        Text("↑ Ghi: %.0f KB/s".format(diskWriteKBs), color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Mạng (Network)",
                subtitle = if (networkUnsupported) "Không hỗ trợ" else "%.0f KB/s ↓".format(downloadKBs),
                percent = null,
                graphValues = if (networkUnsupported) null else downloadHistory,
                icon = Icons.Default.Wifi
            ) {
                if (networkUnsupported) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Thiết bị không hỗ trợ TrafficStats.",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("↓ Tải xuống: %.0f KB/s".format(downloadKBs), color = TextSecondary, fontSize = 12.sp)
                        Text("↑ Tải lên: %.0f KB/s".format(uploadKBs), color = TextSecondary, fontSize = 12.sp)
                    }
                    Text(
                        "Tổng từ lúc bật máy — số liệu thật từ TrafficStats",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Pin",
                subtitle = "$batteryPercent%" + if (isCharging) " (Đang sạc)" else "",
                percent = batteryPercent / 100f,
                graphValues = null,
                icon = Icons.Default.BatteryFull
            )
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
fun CpuCoreBar(core: CpuCoreInfo) {
    val cur = core.currentMhz
    val max = core.maxMhz ?: 3000
    val fraction = if (cur != null && max > 0) (cur.toFloat() / max.toFloat()).coerceIn(0f, 1f) else 0f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Nhân ${core.coreIndex}",
            color = TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.width(52.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(BgDark)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .background(
                        Brush.horizontalGradient(listOf(AccentTealDim, AccentTeal)),
                        RoundedCornerShape(4.dp)
                    )
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            if (cur != null) "$cur MHz" else "N/A",
            color = TextPrimary,
            fontSize = 11.sp,
            modifier = Modifier.width(72.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

@Composable
fun PerfCard(
    title: String,
    subtitle: String,
    percent: Float?,
    graphValues: List<Float>?,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    extraContent: (@Composable ColumnScope.() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(BgPanel, BgPanel.copy(alpha = 0.9f))),
                RoundedCornerShape(12.dp)
            )
            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = AccentTeal,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
            Text(subtitle, color = AccentTeal, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(modifier = Modifier.height(10.dp))

        if (percent != null) {
            LinearProgressIndicator(
                progress = { percent },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = AccentTeal,
                trackColor = BgDark
            )
        }

        if (graphValues != null && graphValues.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(BgDark, RoundedCornerShape(8.dp))
            ) {
                val w = size.width
                val h = size.height

                // Lưới nền giống PC
                for (i in 1..3) {
                    val y = h * i / 4
                    drawLine(
                        color = BorderColor.copy(alpha = 0.6f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                if (graphValues.size > 1) {
                    val stepX = w / (40 - 1).coerceAtLeast(1)
                    val linePath = androidx.compose.ui.graphics.Path()
                    val fillPath = androidx.compose.ui.graphics.Path()

                    graphValues.forEachIndexed { index, value ->
                        val x = index * stepX
                        val y = h - (value * h)
                        if (index == 0) {
                            linePath.moveTo(x, y)
                            fillPath.moveTo(x, h)
                            fillPath.lineTo(x, y)
                        } else {
                            linePath.lineTo(x, y)
                            fillPath.lineTo(x, y)
                        }
                    }
                    val lastX = (graphValues.size - 1) * stepX
                    fillPath.lineTo(lastX, h)
                    fillPath.close()

                    // Vùng tô gradient mờ dần dưới đường line, giống Performance tab trên PC
                    drawPath(
                        fillPath,
                        brush = Brush.verticalGradient(
                            listOf(AccentTeal.copy(alpha = 0.35f), Color.Transparent)
                        )
                    )
                    drawPath(linePath, color = AccentTeal, style = Stroke(width = 3.5f))
                }
            }
        }

        extraContent?.let {
            Spacer(modifier = Modifier.height(8.dp))
            it()
        }
    }
}

// ---------------------------------------------------------------------------------
// TAB 3: STARTUP
// ---------------------------------------------------------------------------------

@Composable
fun StartupScreen() {
    val context = LocalContext.current
    var startupApps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        startupApps = loadBootReceiverApps(context)
        loading = false
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgPanel)
                .padding(12.dp)
        ) {
            Text(
                "Các app dưới đây có thể tự khởi động cùng máy. Android không cho phép " +
                        "tắt/bật quyền này trực tiếp trong app — nhấn vào từng app để mở " +
                        "Cài đặt hệ thống và tắt thủ công.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
        HorizontalDivider(color = BorderColor, thickness = 1.dp)

        if (loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentTeal)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(startupApps) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                intent.data = Uri.parse("package:${app.packageName}")
                                context.startActivity(intent)
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val bitmap = remember(app.packageName) { app.icon.toBitmapSafe() }
                        if (bitmap != null) {
                            androidx.compose.foundation.Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(app.name, color = TextPrimary, fontSize = 14.sp)
                            Text(app.packageName, color = TextSecondary, fontSize = 11.sp)
                        }
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }
    }
}

fun loadBootReceiverApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_BOOT_COMPLETED)
    val receivers = pm.queryBroadcastReceivers(intent, PackageManager.GET_META_DATA)
    val packageNames = receivers.map { it.activityInfo.packageName }.distinct()

    return packageNames.mapNotNull { pkgName ->
        try {
            val appInfo = pm.getApplicationInfo(pkgName, 0)
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem) return@mapNotNull null
            AppEntry(
                name = pm.getApplicationLabel(appInfo).toString(),
                packageName = pkgName,
                icon = pm.getApplicationIcon(appInfo),
                sizeMb = 0.0,
                isSystemApp = isSystem
            )
        } catch (e: Exception) {
            null
        }
    }.sortedBy { it.name }
}

// ---------------------------------------------------------------------------------
// ĐỌC CPU THẬT TỪ SYSFS — cùng cách CPU-Z Mobile làm (không cần root)
// ---------------------------------------------------------------------------------

data class CpuCoreInfo(
    val coreIndex: Int,
    val currentMhz: Int?, // null nếu máy chặn đọc (một số hãng giới hạn từ Android 8+)
    val minMhz: Int?,
    val maxMhz: Int?
)

data class CpuHardwareInfo(
    val hardware: String?,   // dòng "Hardware" trong /proc/cpuinfo
    val processor: String?,  // dòng "model name" hoặc "Processor"
    val abi: String,
    val coreCount: Int
)

// Đọc 1 dòng số nguyên từ file sysfs, trả về null nếu không đọc được (bị chặn quyền)
private fun readSysfsInt(path: String): Int? {
    return try {
        File(path).readText().trim().toIntOrNull()
    } catch (e: Exception) {
        null // bị chặn bởi SELinux/nhà sản xuất, hoặc file không tồn tại
    }
}

fun readCpuCoreFrequencies(coreCount: Int): List<CpuCoreInfo> {
    return (0 until coreCount).map { i ->
        val base = "/sys/devices/system/cpu/cpu$i/cpufreq"
        val curKhz = readSysfsInt("$base/scaling_cur_freq")
        val minKhz = readSysfsInt("$base/cpuinfo_min_freq")
        val maxKhz = readSysfsInt("$base/cpuinfo_max_freq")
        CpuCoreInfo(
            coreIndex = i,
            currentMhz = curKhz?.let { it / 1000 },
            minMhz = minKhz?.let { it / 1000 },
            maxMhz = maxKhz?.let { it / 1000 }
        )
    }
}

fun readCpuHardwareInfo(): CpuHardwareInfo {
    var hardware: String? = null
    var processor: String? = null
    try {
        File("/proc/cpuinfo").forEachLine { line ->
            when {
                line.startsWith("Hardware") -> hardware = line.substringAfter(":").trim()
                line.startsWith("model name") -> processor = line.substringAfter(":").trim()
                line.startsWith("Processor") && processor == null -> processor = line.substringAfter(":").trim()
            }
        }
    } catch (e: Exception) {
        // Không đọc được /proc/cpuinfo, sẽ hiện Build.HARDWARE thay thế bên dưới
    }
    return CpuHardwareInfo(
        hardware = hardware ?: Build.HARDWARE,
        processor = processor ?: Build.BOARD,
        abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "N/A",
        coreCount = Runtime.getRuntime().availableProcessors()
    )
}

// ---------------------------------------------------------------------------------
// CPU % TỔNG THỂ — đọc /proc/stat, tính theo delta giữa 2 lần đọc (giống cách Task Manager
// thật tính %CPU: so sánh jiffies "busy" và "idle" giữa 2 thời điểm)
// ---------------------------------------------------------------------------------

data class CpuStatSnapshot(val idle: Long, val total: Long)

fun readCpuStatSnapshot(): CpuStatSnapshot? {
    return try {
        val line = File("/proc/stat").bufferedReader().readLine() ?: return null
        // Dòng đầu dạng: "cpu  12345 678 9012 34567 890 0 12 0 0 0"
        val parts = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (parts.size < 4) return null
        val user = parts[0]; val nice = parts[1]; val system = parts[2]; val idle = parts[3]
        val iowait = parts.getOrElse(4) { 0L }
        val irq = parts.getOrElse(5) { 0L }
        val softirq = parts.getOrElse(6) { 0L }
        val steal = parts.getOrElse(7) { 0L }
        val idleAll = idle + iowait
        val total = user + nice + system + idleAll + irq + softirq + steal
        CpuStatSnapshot(idleAll, total)
    } catch (e: Exception) {
        null // Bị chặn quyền đọc /proc/stat (hiếm, nhưng vài máy hãng lạ có thể chặn)
    }
}

fun calcCpuUsagePercent(prev: CpuStatSnapshot, curr: CpuStatSnapshot): Float? {
    val totalDelta = curr.total - prev.total
    val idleDelta = curr.idle - prev.idle
    if (totalDelta <= 0) return null
    return ((totalDelta - idleDelta).toFloat() / totalDelta.toFloat()).coerceIn(0f, 1f)
}

// ---------------------------------------------------------------------------------
// TỐC ĐỘ MẠNG THẬT — TrafficStats, tính delta byte giữa các lần đọc mỗi giây
// ---------------------------------------------------------------------------------

data class NetworkSnapshot(val rxBytes: Long, val txBytes: Long, val timeMs: Long)

fun readNetworkSnapshot(): NetworkSnapshot {
    val rx = android.net.TrafficStats.getTotalRxBytes()
    val tx = android.net.TrafficStats.getTotalTxBytes()
    return NetworkSnapshot(rx, tx, System.currentTimeMillis())
}

// Trả về Pair(downloadKBs, uploadKBs). Nếu thiết bị không hỗ trợ TrafficStats trả về -1 cho cả 2.
fun calcNetworkSpeedKBs(prev: NetworkSnapshot, curr: NetworkSnapshot): Pair<Double, Double> {
    if (prev.rxBytes == android.net.TrafficStats.UNSUPPORTED.toLong() ||
        curr.rxBytes == android.net.TrafficStats.UNSUPPORTED.toLong()
    ) return -1.0 to -1.0
    val dtSec = ((curr.timeMs - prev.timeMs).coerceAtLeast(1)) / 1000.0
    val downKBs = ((curr.rxBytes - prev.rxBytes).coerceAtLeast(0)) / 1024.0 / dtSec
    val upKBs = ((curr.txBytes - prev.txBytes).coerceAtLeast(0)) / 1024.0 / dtSec
    return downKBs to upKBs
}

// ---------------------------------------------------------------------------------
// TỐC ĐỘ ĐĨA THẬT — đọc /proc/diskstats, cộng dồn số sector đọc/ghi của các block device
// chính (mmcblk, sda, dm-*), quy đổi ra KB/s theo delta mỗi giây
// ---------------------------------------------------------------------------------

data class DiskSnapshot(val readSectors: Long, val writeSectors: Long, val timeMs: Long)

fun readDiskSnapshot(): DiskSnapshot? {
    return try {
        var readSectors = 0L
        var writeSectors = 0L
        File("/proc/diskstats").forEachLine { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 10) return@forEachLine
            val deviceName = parts[2]
            // Chỉ tính thiết bị lưu trữ chính, bỏ qua các phân vùng loop/ram
            if (deviceName.startsWith("mmcblk0") && !deviceName.contains("p") ||
                deviceName.startsWith("sda") && deviceName.length <= 4 ||
                deviceName.startsWith("dm-")
            ) {
                readSectors += parts[5].toLongOrNull() ?: 0L
                writeSectors += parts[9].toLongOrNull() ?: 0L
            }
        }
        DiskSnapshot(readSectors, writeSectors, System.currentTimeMillis())
    } catch (e: Exception) {
        null // Nhiều máy Android 10+ chặn đọc /proc/diskstats vì lý do bảo mật (SELinux)
    }
}

// Sector chuẩn Linux = 512 byte. Trả về Pair(readKBs, writeKBs)
fun calcDiskSpeedKBs(prev: DiskSnapshot, curr: DiskSnapshot): Pair<Double, Double> {
    val dtSec = ((curr.timeMs - prev.timeMs).coerceAtLeast(1)) / 1000.0
    val readKBs = ((curr.readSectors - prev.readSectors).coerceAtLeast(0)) * 512.0 / 1024.0 / dtSec
    val writeKBs = ((curr.writeSectors - prev.writeSectors).coerceAtLeast(0)) * 512.0 / 1024.0 / dtSec
    return readKBs to writeKBs
}
