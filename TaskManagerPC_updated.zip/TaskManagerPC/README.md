# Task Manager PC-style (Android)

App Task Manager cho điện thoại, giao diện lấy cảm hứng từ Task Manager trên Windows
(nền tối, 3 tab: Processes / Performance / Startup), viết bằng Kotlin + Jetpack Compose.

## Cách build ra file APK

1. Cài **Android Studio** (bản mới nhất): https://developer.android.com/studio
2. Mở Android Studio → **Open** → chọn thư mục `TaskManagerPC` (thư mục chứa file `settings.gradle.kts`)
3. Đợi Gradle sync xong (lần đầu sẽ tải Gradle + SDK, cần mạng)
4. Vào menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. File APK debug sẽ nằm ở: `app/build/outputs/apk/debug/app-debug.apk`
6. Cắm điện thoại qua USB (bật **Chế độ nhà phát triển** + **Gỡ lỗi USB**) rồi bấm nút Run (▶) để cài thẳng lên máy, hoặc copy file APK qua điện thoại rồi cài thủ công.

## Cấu trúc project

```
TaskManagerPC/
├── app/
│   ├── build.gradle.kts          # cấu hình module app, thư viện dùng
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/example/taskmanager/
│       │   ├── MainActivity.kt   # toàn bộ UI + logic (3 tab)
│       │   └── ui/theme/         # màu sắc, theme dark giống PC
│       └── res/                  # icon, string, theme XML
├── build.gradle.kts
└── settings.gradle.kts
```

## 3 tab hiện có

- **Processes**: liệt kê app đã cài (icon, tên, package), cột **Memory** hiển thị RAM thật
  (PSS) đang dùng của từng app (cập nhật mỗi ~2.5 giây, giống cột Memory trên Windows Task
  Manager), cột thời gian dùng hôm nay (nếu đã cấp Usage Access), nút "Kết thúc".
  Sắp xếp được theo Memory / Thời gian dùng / Dung lượng cài đặt.
- **Performance**: RAM, bộ nhớ trong, pin, số nhân CPU, tần số từng nhân, tốc độ mạng —
  **số liệu thật** lấy từ hệ thống Android (ActivityManager, TrafficStats, sysfs, /proc).
  Có đồ thị real-time cho RAM & CPU. Khi máy chặn `/proc/stat` (Android 8+), app tự
  chuyển sang ước tính %CPU từ tần số nhân (cùng cách CPU-Z / CPU Stats dùng).
- **Startup**: liệt kê các app có đăng ký nhận sự kiện khởi động máy (`BOOT_COMPLETED`),
  bấm vào để mở Cài đặt và tắt quyền tự khởi động thủ công.

## Giới hạn quan trọng (do chính sách bảo mật Android, không phải do code)

- Cột Memory dùng `ActivityManager.getProcessMemoryInfo` (PSS). Đây là số liệu gần đúng
  nhất mà app thường (không root) lấy được. Trên một số máy Android mới, hệ thống có thể
  trả về 0 cho process của app khác vì chính sách bảo mật — khi đó cột Memory sẽ hiện "—".
- Từ Android 8.0, SELinux chặn app thường đọc `/proc/stat` → không có %CPU tổng “chuẩn”.
  App đã fallback tự động: ước tính %CPU từ tần số từng nhân (sysfs), hiển thị ≈xx%.
- Từ Android 10+, nhiều máy cũng chặn `/proc/diskstats` → không đọc được tốc độ đọc/ghi đĩa real-time.
- Không thể tự động Force Stop app khác bằng code — chỉ mở được màn hình Cài đặt để người
  dùng tự bấm.
- Cần cấp quyền thủ công một số trường hợp (ví dụ Android 11+ có thể cần bật
  "Cho phép truy cập tất cả ứng dụng" nếu Google Play Console giới hạn).

## Gợi ý khi đưa qua ChatGPT/Grok chỉnh giao diện

- File cần đưa: `MainActivity.kt` (toàn bộ UI) và `ui/theme/Color.kt`, `Theme.kt` (bảng màu).
- Có thể yêu cầu AI thêm: animation chuyển tab, thêm tab "Details"/"Services" giả lập,
  làm đồ thị Performance đẹp hơn (nhiều màu, gradient), thêm dark/light switch, splash screen, icon đẹp hơn.
