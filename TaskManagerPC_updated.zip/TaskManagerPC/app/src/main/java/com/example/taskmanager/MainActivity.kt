package com.example.taskmanager

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.os.StatFs
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.window.Dialog
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.taskmanager.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashLogger(this)
        setContent {
            TaskManagerPCTheme {
                var crashLog by remember { mutableStateOf(readLastCrashLog(this)) }
                if (crashLog != null) {
                    AlertDialog(
                        onDismissRequest = { },
                        title = { Text("App vừa bị crash lần trước") },
                        text = {
                            Column(modifier = Modifier.heightIn(max = 400.dp)) {
                                androidx.compose.foundation.lazy.LazyColumn {
                                    item {
                                        Text(
                                            crashLog ?: "",
                                            fontSize = 11.sp,
                                            color = TextPrimary
                                        )
                                    }
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                clearCrashLog(this@MainActivity)
                                crashLog = null
                            }) { Text("Đã đọc, đóng lại") }
                        }
                    )
                }
                TaskManagerApp()
            }
        }
    }
}

// Ghi lại lỗi crash gần nhất vào bộ nhớ NGOÀI riêng của app (Android/data/<package>/files),
// để có thể mở bằng ZArchiver hoặc app quản lý file khác mà không cần root, không cần USB/adb.
private const val CRASH_LOG_FILE = "last_crash.txt"

// Thư mục lưu log: ưu tiên bộ nhớ ngoài riêng của app (xem được bằng ZArchiver tại
// Android/data/com.example.taskmanager/files/), nếu máy không có bộ nhớ ngoài thì dùng bộ nhớ trong.
private fun logDir(context: Context): File {
    val appContext = context.applicationContext
    return appContext.getExternalFilesDir(null) ?: appContext.filesDir
}

fun installCrashLogger(context: Context) {
    val appContext = context.applicationContext
    val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
        try {
            val sw = java.io.StringWriter()
            throwable.printStackTrace(java.io.PrintWriter(sw))
            File(logDir(appContext), CRASH_LOG_FILE).writeText(sw.toString())
        } catch (e: Exception) {
            // Không ghi được log thì thôi, vẫn để crash xảy ra bình thường bên dưới
        }
        defaultHandler?.uncaughtException(thread, throwable)
    }
}

fun readLastCrashLog(context: Context): String? {
    val f = File(logDir(context), CRASH_LOG_FILE)
    val crash = if (f.exists()) f.readText() else null
    val errors = readErrorLog(context)
    return when {
        crash != null && errors != null -> "=== CRASH ===\n$crash\n\n=== LỖI ĐÃ BẮT (không crash nhưng có lỗi) ===\n$errors"
        crash != null -> crash
        errors != null -> "=== LỖI ĐÃ BẮT (không crash nhưng có lỗi) ===\n$errors"
        else -> null
    }
}

fun clearCrashLog(context: Context) {
    File(logDir(context), CRASH_LOG_FILE).delete()
    File(logDir(context), ERROR_LOG_FILE).delete()
}

// Ghi log cho các lỗi bị try-catch bắt âm thầm (không làm crash app, nhưng có thể
// khiến 1 màn hình bị trắng/loading mãi). Nối thêm vào cuối file, kèm nhãn để biết lỗi ở đâu.
private const val ERROR_LOG_FILE = "last_errors.txt"

fun logCaughtError(context: Context, tag: String, e: Throwable) {
    try {
        val sw = java.io.StringWriter()
        e.printStackTrace(java.io.PrintWriter(sw))
        val entry = "[$tag] ${java.util.Date()}\n${sw}\n---\n"
        val f = File(logDir(context), ERROR_LOG_FILE)
        f.appendText(entry)
    } catch (ex: Exception) {
        // ghi log mà cũng lỗi thì thôi, bỏ qua
    }
}

private fun readErrorLog(context: Context): String? {
    val f = File(logDir(context), ERROR_LOG_FILE)
    return if (f.exists()) f.readText() else null
}

data class AppEntry(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable,
    val sizeMb: Double,
    val isSystemApp: Boolean,
    val foregroundMinutesToday: Double = 0.0, // thời gian dùng thật hôm nay, từ UsageStatsManager
    val lastUsedMs: Long = 0L,
    val memoryMb: Double = 0.0 // RAM thật (PSS) đang dùng, 0 nếu app không chạy
)

data class AppDetail(
    val versionName: String?,
    val versionCode: Long,
    val installedDate: String,
    val updatedDate: String,
    val targetSdk: Int,
    val minSdk: Int,
    val dataDirMb: Double,
    val permissions: List<String>
)

// Đọc thông tin chi tiết THẬT của 1 app từ PackageManager, dùng cho màn "Thông tin chi tiết"
fun loadAppDetail(context: Context, packageName: String): AppDetail? {
    return try {
        val pm = context.packageManager
        val flags = PackageManager.GET_PERMISSIONS
        val info = pm.getPackageInfo(packageName, flags)
        val fmt = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        val versionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) info.longVersionCode
        else @Suppress("DEPRECATION") info.versionCode.toLong()
        val dataDir = File(info.applicationInfo?.dataDir ?: "")
        val dataDirMb = if (dataDir.exists()) folderSizeBytes(dataDir) / (1024.0 * 1024.0) else 0.0
        val requestedPerms = info.requestedPermissions?.toList() ?: emptyList()
        AppDetail(
            versionName = info.versionName,
            versionCode = versionCode,
            installedDate = fmt.format(java.util.Date(info.firstInstallTime)),
            updatedDate = fmt.format(java.util.Date(info.lastUpdateTime)),
            targetSdk = info.applicationInfo?.targetSdkVersion ?: 0,
            minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) info.applicationInfo?.minSdkVersion ?: 0 else 0,
            dataDirMb = dataDirMb,
            permissions = requestedPerms
        )
    } catch (e: Exception) {
        logCaughtError(context, "loadAppDetail", e)
        null
    }
}

private fun folderSizeBytes(dir: File, depth: Int = 0): Long {
    if (depth > 4) return 0L // tránh đệ quy quá sâu, tốn thời gian
    return try {
        var total = 0L
        dir.listFiles()?.forEach { f ->
            total += if (f.isDirectory) folderSizeBytes(f, depth + 1) else f.length()
        }
        total
    } catch (e: Exception) {
        0L
    }
}

// Kiểm tra xem người dùng đã cấp quyền "Usage Access" chưa (cần bật thủ công trong Settings)
fun hasUsageAccessPermission(context: Context): Boolean {
    val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    val mode = appOps.checkOpNoThrow(
        AppOpsManager.OPSTR_GET_USAGE_STATS,
        Process.myUid(),
        context.packageName
    )
    return mode == AppOpsManager.MODE_ALLOWED
}

// Lấy thời gian sử dụng THẬT của từng app trong ngày hôm nay, dùng UsageStatsManager
fun loadUsageStatsToday(context: Context): Map<String, Double> {
    val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
    val end = System.currentTimeMillis()
    val start = end - (24L * 60 * 60 * 1000) // 24 giờ gần nhất
    val statsList = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, start, end)
    val result = mutableMapOf<String, Double>()
    statsList?.forEach { stat ->
        val minutes = stat.totalTimeInForeground / 60000.0
        if (minutes > 0) {
            // Nếu app xuất hiện nhiều lần (nhiều interval), cộng dồn
            result[stat.packageName] = (result[stat.packageName] ?: 0.0) + minutes
        }
    }
    return result
}

// Lấy RAM thật (PSS) đang dùng của từng package từ các process đang chạy.
// Dùng ActivityManager.getProcessMemoryInfo — đây là số liệu gần đúng nhất mà app thường
// (không root) lấy được, giống cột Memory trên Windows Task Manager.
// Lưu ý: từ Android mới một số máy có thể trả về 0 cho process của app khác vì chính sách bảo mật.
fun loadProcessMemoryMap(context: Context): Map<String, Double> {
    return try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val running = am.runningAppProcesses ?: return emptyMap()
        val result = mutableMapOf<String, Double>()
        for (proc in running) {
            try {
                val memInfos = am.getProcessMemoryInfo(intArrayOf(proc.pid))
                if (memInfos != null && memInfos.isNotEmpty()) {
                    // totalPss đơn vị KB → chuyển sang MB
                    val pssMb = memInfos[0].totalPss / 1024.0
                    val pkgs = proc.pkgList
                    if (pkgs != null && pkgs.isNotEmpty()) {
                        // Chia đều PSS cho các package cùng process (tránh đếm trùng quá mức)
                        val share = pssMb / pkgs.size
                        for (pkg in pkgs) {
                            result[pkg] = (result[pkg] ?: 0.0) + share
                        }
                    } else {
                        val pkg = proc.processName.substringBefore(':')
                        result[pkg] = (result[pkg] ?: 0.0) + pssMb
                    }
                }
            } catch (_: Exception) {
                // bỏ qua process lỗi
            }
        }
        result
    } catch (e: Exception) {
        emptyMap()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskManagerApp() {
    val context = LocalContext.current
    val tabs = listOf(
        Triple("Processes", Icons.Default.List, "Ứng dụng"),
        Triple("Performance", Icons.Default.Speed, "Hiệu năng"),
        Triple("Startup", Icons.Default.PowerSettingsNew, "Khởi động")
    )
    var selectedTab by remember { mutableStateOf(0) }
    var showLogScreen by remember { mutableStateOf(false) }

    if (showLogScreen) {
        LogScreen(onBack = { showLogScreen = false })
        return
    }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            Column(
                modifier = Modifier.background(
                    Brush.verticalGradient(listOf(BgHeader, BgHeader.copy(alpha = 0.96f)))
                )
            ) {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Memory,
                                contentDescription = null,
                                tint = AccentTeal,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Task Manager",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { showLogScreen = true }) {
                            Icon(
                                Icons.Default.BugReport,
                                contentDescription = "Nhật ký lỗi",
                                tint = TextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent,
                        titleContentColor = TextPrimary
                    )
                )
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    contentColor = AccentTeal,
                    indicator = { positions ->
                        if (selectedTab < positions.size) {
                            Box(
                                modifier = Modifier
                                    .tabIndicatorOffset(positions[selectedTab])
                                    .height(3.dp)
                                    .padding(horizontal = 24.dp)
                                    .background(
                                        Brush.horizontalGradient(listOf(AccentTealDim, AccentTeal)),
                                        RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp)
                                    )
                            )
                        }
                    },
                    divider = { HorizontalDivider(color = BorderColor, thickness = 1.dp) }
                ) {
                    tabs.forEachIndexed { index, (title, icon, _) ->
                        val selected = selectedTab == index
                        Tab(
                            selected = selected,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    title,
                                    fontSize = 13.sp,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    color = if (selected) AccentTeal else TextSecondary
                                )
                            },
                            icon = {
                                Icon(
                                    icon,
                                    contentDescription = null,
                                    tint = if (selected) AccentTeal else TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BgDark)
                .padding(padding)
        ) {
            AnimatedContent(
                targetState = selectedTab,
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally(animationSpec = tween(280)) { w -> dir * w / 4 } +
                            fadeIn(animationSpec = tween(280))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(280)) { w -> -dir * w / 4 } +
                                    fadeOut(animationSpec = tween(280)))
                },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    0 -> ProcessesScreen()
                    1 -> PerformanceScreen()
                    2 -> StartupScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var logText by remember { mutableStateOf(readLastCrashLog(context) ?: "Chưa có lỗi nào được ghi lại.") }

    Scaffold(
        containerColor = BgDark,
        topBar = {
            TopAppBar(
                title = { Text("Nhật ký lỗi", fontSize = 16.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Quay lại", tint = TextPrimary)
                    }
                },
                actions = {
                    IconButton(onClick = {
                        clearCrashLog(context)
                        logText = "Chưa có lỗi nào được ghi lại."
                    }) {
                        Icon(Icons.Default.Delete, contentDescription = "Xoá log", tint = TextSecondary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = BgHeader,
                    titleContentColor = TextPrimary
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(BgDark)
                .padding(padding)
        ) {
            androidx.compose.foundation.lazy.LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                item {
                    Text(
                        logText,
                        color = TextPrimary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------------
// TAB 1: PROCESSES
// ---------------------------------------------------------------------------------

@Composable
fun ProcessesScreen() {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var showSystemApps by remember { mutableStateOf(false) }
    var hasUsagePermission by remember { mutableStateOf(hasUsageAccessPermission(context)) }
    // 0 = Memory (RAM), 1 = Thời gian dùng, 2 = Dung lượng cài đặt
    var sortMode by remember { mutableStateOf(0) }
    var selectedApp by remember { mutableStateOf<AppEntry?>(null) }

    // Kiểm tra lại quyền mỗi khi quay lại màn hình (sau khi bật trong Settings)
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) {
                hasUsagePermission = hasUsageAccessPermission(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Tải danh sách app + usage 1 lần, sau đó cứ 2.5s cập nhật memory (RAM thật) của process đang chạy
    LaunchedEffect(hasUsagePermission) {
        try {
            val loadedApps = withContext(Dispatchers.IO) {
                val u = if (hasUsagePermission) loadUsageStatsToday(context) else emptyMap()
                val m = loadProcessMemoryMap(context)
                loadInstalledApps(context, u, m)
            }
            apps = loadedApps
        } catch (e: Exception) {
            logCaughtError(context, "ProcessesScreen.load", e)
            apps = emptyList()
        }
        loading = false

        // Cập nhật memory định kỳ (giống Task Manager Windows refresh)
        while (true) {
            delay(2500)
            try {
                val memMap = withContext(Dispatchers.IO) { loadProcessMemoryMap(context) }
                apps = apps.map { app ->
                    app.copy(memoryMb = memMap[app.packageName] ?: 0.0)
                }
            } catch (e: Exception) {
                logCaughtError(context, "ProcessesScreen.memRefresh", e)
            }
        }
    }

    val filtered = remember(apps, showSystemApps, sortMode) {
        val base = if (showSystemApps) apps else apps.filter { !it.isSystemApp }
        when (sortMode) {
            0 -> base.sortedByDescending { it.memoryMb }
            1 -> base.sortedByDescending { it.foregroundMinutesToday }
            else -> base.sortedByDescending { it.sizeMb }
        }
    }

    val sortLabel = when (sortMode) {
        0 -> "Đang sắp: Memory"
        1 -> "Đang sắp: Thời gian dùng"
        else -> "Đang sắp: Dung lượng"
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (!hasUsagePermission) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(WarnOrange.copy(alpha = 0.18f), WarnOrange.copy(alpha = 0.06f))
                        ),
                        RoundedCornerShape(10.dp)
                    )
                    .border(1.dp, WarnOrange.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = WarnOrange)
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "Cần cấp quyền để xem thời gian dùng THẬT của từng app",
                        color = TextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        "Bấm để mở Cài đặt → tìm \"Task Manager\" → bật Usage Access",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                TextButton(onClick = {
                    context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }) {
                    Text("Mở Cài đặt", color = AccentTeal, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Header giống bảng cột trên Windows Task Manager: Tên | Memory | (Dùng hôm nay) | Kết thúc
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgHeader)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(
                "Tên",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                "Memory",
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.width(72.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
            if (hasUsagePermission) {
                Text(
                    "Dùng hôm nay",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    modifier = Modifier.width(80.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.End
                )
            }
            Spacer(modifier = Modifier.width(70.dp))
        }
        HorizontalDivider(color = BorderColor, thickness = 1.dp)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = showSystemApps,
                onCheckedChange = { showSystemApps = it },
                colors = CheckboxDefaults.colors(checkedColor = AccentTeal)
            )
            Text("Hiện cả app hệ thống", color = TextSecondary, fontSize = 13.sp)
            Spacer(modifier = Modifier.weight(1f))
            TextButton(onClick = {
                sortMode = (sortMode + 1) % (if (hasUsagePermission) 3 else 2)
            }) {
                Text(sortLabel, color = AccentTeal, fontSize = 11.sp)
            }
            Text("${filtered.size} tiến trình", color = TextSecondary, fontSize = 12.sp)
        }

        if (loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentTeal)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filtered) { app ->
                    ProcessRow(app, context, hasUsagePermission, onClick = { selectedApp = app })
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }
    }

    selectedApp?.let { app ->
        AppDetailDialog(app = app, context = context, onDismiss = { selectedApp = null })
    }
}

@Composable
fun ProcessRow(app: AppEntry, context: Context, hasUsagePermission: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .background(BgPanel.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val bitmap = remember(app.packageName) { app.icon.toBitmapSafe() }
        if (bitmap != null) {
            androidx.compose.foundation.Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(BgDark, RoundedCornerShape(8.dp))
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                app.name,
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                app.packageName,
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        // Cột Memory (RAM thật - PSS), giống Windows Task Manager
        val memText = if (app.memoryMb > 0.05) {
            if (app.memoryMb >= 1024)
                "%.2f GB".format(app.memoryMb / 1024.0)
            else
                "%.1f MB".format(app.memoryMb)
        } else {
            "—"
        }
        Text(
            memText,
            color = if (app.memoryMb > 0.05) AccentTeal else TextSecondary,
            fontSize = 12.sp,
            fontWeight = if (app.memoryMb > 0.05) FontWeight.Medium else FontWeight.Normal,
            modifier = Modifier.width(72.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
        // Cột thời gian dùng (nếu có quyền)
        if (hasUsagePermission) {
            val timeText = if (app.foregroundMinutesToday >= 60)
                "%.1f giờ".format(app.foregroundMinutesToday / 60.0)
            else if (app.foregroundMinutesToday > 0)
                "%.0f phút".format(app.foregroundMinutesToday)
            else
                "0 phút"
            Text(
                timeText,
                color = TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.width(80.dp),
                textAlign = androidx.compose.ui.text.style.TextAlign.End
            )
        }
        TextButton(
            onClick = {
                // Thử tắt tiến trình nền THẬT trước (chỉ có tác dụng nếu app đang chạy nền)
                val killed = killAppBackgroundProcess(context, app.packageName)
                if (killed) {
                    Toast.makeText(
                        context,
                        "Đã gửi lệnh tắt tiến trình nền của ${app.name}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                // Vẫn mở thêm màn Cài đặt để người dùng tự Force Stop nếu app đang mở trên màn hình
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.parse("package:${app.packageName}")
                context.startActivity(intent)
            },
            modifier = Modifier.width(70.dp),
            colors = ButtonDefaults.textButtonColors(contentColor = DangerRed)
        ) {
            Text("Kết thúc", color = DangerRed, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun AppDetailDialog(app: AppEntry, context: Context, onDismiss: () -> Unit) {
    var detail by remember(app.packageName) { mutableStateOf<AppDetail?>(null) }
    var loading by remember(app.packageName) { mutableStateOf(true) }

    LaunchedEffect(app.packageName) {
        detail = withContext(Dispatchers.IO) { loadAppDetail(context, app.packageName) }
        loading = false
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgPanel, RoundedCornerShape(14.dp))
                .border(1.dp, BorderColor, RoundedCornerShape(14.dp))
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val bitmap = remember(app.packageName) { app.icon.toBitmapSafe() }
                if (bitmap != null) {
                    androidx.compose.foundation.Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(9.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(app.name, color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        app.packageName,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = BorderColor)
            Spacer(modifier = Modifier.height(14.dp))

            if (loading) {
                Box(modifier = Modifier.fillMaxWidth().height(80.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = AccentTeal)
                }
            } else if (detail == null) {
                Text("Không đọc được thông tin chi tiết của app này.", color = WarnOrange, fontSize = 13.sp)
            } else {
                val d = detail!!
                DetailRow("Phiên bản", "${d.versionName ?: "N/A"} (mã ${d.versionCode})")
                DetailRow("Cài đặt lần đầu", d.installedDate)
                DetailRow("Cập nhật gần nhất", d.updatedDate)
                DetailRow("Target SDK / Min SDK", "${d.targetSdk} / ${d.minSdk}")
                DetailRow("Dung lượng cài đặt", "%.1f MB".format(app.sizeMb))
                DetailRow("Dữ liệu app (data)", "%.1f MB".format(d.dataDirMb))
                DetailRow(
                    "Memory (RAM đang dùng)",
                    if (app.memoryMb > 0.05) "%.1f MB (PSS)".format(app.memoryMb) else "Không chạy / 0 MB"
                )
                DetailRow("Loại", if (app.isSystemApp) "App hệ thống" else "App người dùng")

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "Quyền được yêu cầu (${d.permissions.size})",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(modifier = Modifier.heightIn(max = 160.dp).verticalScroll(rememberScrollState())) {
                    if (d.permissions.isEmpty()) {
                        Text("Không yêu cầu quyền nào", color = TextSecondary, fontSize = 11.sp)
                    } else {
                        d.permissions.forEach { p ->
                            Text(
                                "• " + p.substringAfterLast('.'),
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    intent.data = Uri.parse("package:${app.packageName}")
                    context.startActivity(intent)
                }) {
                    Text("Mở Cài đặt", color = AccentTeal, fontSize = 13.sp)
                }
                Spacer(modifier = Modifier.width(4.dp))
                TextButton(onClick = onDismiss) {
                    Text("Đóng", color = TextSecondary, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = TextSecondary, fontSize = 12.sp)
        Text(value, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

fun android.graphics.drawable.Drawable.toBitmapSafe(): android.graphics.Bitmap? {
    return try {
        val bmp = android.graphics.Bitmap.createBitmap(
            intrinsicWidth.coerceAtLeast(1),
            intrinsicHeight.coerceAtLeast(1),
            android.graphics.Bitmap.Config.ARGB_8888
        )
        val canvas = android.graphics.Canvas(bmp)
        setBounds(0, 0, canvas.width, canvas.height)
        draw(canvas)
        bmp
    } catch (e: Exception) {
        null
    }
}

fun loadInstalledApps(
    context: Context,
    usageMap: Map<String, Double> = emptyMap(),
    memoryMap: Map<String, Double> = emptyMap()
): List<AppEntry> {
    val pm = context.packageManager
    val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
    return packages.mapNotNull { appInfo ->
        try {
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            val sourceFile = File(appInfo.sourceDir)
            val sizeMb = sourceFile.length() / (1024.0 * 1024.0)
            AppEntry(
                name = pm.getApplicationLabel(appInfo).toString(),
                packageName = appInfo.packageName,
                icon = pm.getApplicationIcon(appInfo),
                sizeMb = sizeMb,
                isSystemApp = isSystem,
                foregroundMinutesToday = usageMap[appInfo.packageName] ?: 0.0,
                memoryMb = memoryMap[appInfo.packageName] ?: 0.0
            )
        } catch (e: Exception) {
            null
        }
    }
}

// Thử tắt tiến trình nền THẬT của 1 app (chỉ tắt được app đang chạy NỀN,
// không tắt được app đang mở trên màn hình — đây là giới hạn của Android, không phải lỗi code)
fun killAppBackgroundProcess(context: Context, packageName: String): Boolean {
    return try {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        am.killBackgroundProcesses(packageName)
        true
    } catch (e: Exception) {
        false
    }
}

// ---------------------------------------------------------------------------------
// TAB 2: PERFORMANCE
// ---------------------------------------------------------------------------------

// Gói tất cả kết quả đọc hệ thống (chạy ở luồng nền) lại thành 1 object,
// để chuyển về luồng chính gán vào state 1 lần, tránh việc mỗi dòng đọc file chặn UI.
data class PerfSnapshot(
    val memInfo: ActivityManager.MemoryInfo,
    val stat: StatFs,
    val battPct: Int?,
    val charging: Boolean?,
    val freqs: List<CpuCoreInfo>,
    val cpuSnap: CpuStatSnapshot?,
    val loadAvg: LoadAvg?,
    val netSnap: NetworkSnapshot,
    val diskSnap: DiskSnapshot?
)

@Composable
fun PerformanceScreen() {
    val context = LocalContext.current
    var ramUsedPercent by remember { mutableStateOf(0f) }
    var ramUsedGb by remember { mutableStateOf(0.0) }
    var ramTotalGb by remember { mutableStateOf(0.0) }
    var storageUsedPercent by remember { mutableStateOf(0f) }
    var storageUsedGb by remember { mutableStateOf(0.0) }
    var storageTotalGb by remember { mutableStateOf(0.0) }
    var batteryPercent by remember { mutableStateOf(0) }
    var isCharging by remember { mutableStateOf(false) }
    val cpuCores = remember { Runtime.getRuntime().availableProcessors() }

    val ramHistory = remember { mutableStateListOf<Float>() }
    val cpuHardware = remember { readCpuHardwareInfo() }
    var cpuCoreInfo by remember { mutableStateOf<List<CpuCoreInfo>>(emptyList()) }
    var cpuReadBlocked by remember { mutableStateOf(false) }

    // CPU % tổng thể (giống thanh CPU trên Windows Task Manager)
    val cpuUsageHistory = remember { mutableStateListOf<Float>() }
    var cpuUsagePercent by remember { mutableStateOf(0f) }
    var cpuUsageBlocked by remember { mutableStateOf(false) }
    var cpuUsageEstimated by remember { mutableStateOf(false) } // true = ước tính từ tần số nhân
    var loadAvg by remember { mutableStateOf<LoadAvg?>(null) }

    // Tốc độ mạng thật
    var downloadKBs by remember { mutableStateOf(0.0) }
    var uploadKBs by remember { mutableStateOf(0.0) }
    val downloadHistory = remember { mutableStateListOf<Float>() }
    var networkUnsupported by remember { mutableStateOf(false) }

    // Tốc độ đĩa thật
    var diskReadKBs by remember { mutableStateOf(0.0) }
    var diskWriteKBs by remember { mutableStateOf(0.0) }
    var diskReadBlocked by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

        var prevCpuSnap = withContext(Dispatchers.IO) { readCpuStatSnapshot() }
        var prevNetSnap = readNetworkSnapshot()
        var prevDiskSnap = withContext(Dispatchers.IO) { readDiskSnapshot() }
        diskReadBlocked = prevDiskSnap == null

        while (true) {
            try {
                // Toàn bộ phần đọc file/hệ thống (tốn thời gian) chạy ở luồng nền,
                // chỉ kết quả cuối cùng mới được gán vào state ở luồng chính, tránh giật UI.
                val snapshot = withContext(Dispatchers.IO) {
                    val memInfo = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(memInfo)

                    val stat = StatFs(context.filesDir.path)

                    var battPct: Int? = null
                    var charging: Boolean? = null
                    try {
                        battPct = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                        charging = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) ==
                                BatteryManager.BATTERY_STATUS_CHARGING
                    } catch (e: Exception) {
                        logCaughtError(context, "PerformanceScreen.battery", e)
                    }

                    val freqs = readCpuCoreFrequencies(cpuCores)
                    val currCpuSnap = readCpuStatSnapshot()
                    val loadAvg = readLoadAvg()
                    val currNetSnap = readNetworkSnapshot()
                    val currDiskSnap = readDiskSnapshot()

                    PerfSnapshot(memInfo, stat, battPct, charging, freqs, currCpuSnap, loadAvg, currNetSnap, currDiskSnap)
                }

                val used = snapshot.memInfo.totalMem - snapshot.memInfo.availMem
                ramUsedPercent = used.toFloat() / snapshot.memInfo.totalMem.toFloat()
                ramUsedGb = used / (1024.0 * 1024.0 * 1024.0)
                ramTotalGb = snapshot.memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)

                val totalBytes = snapshot.stat.totalBytes
                val availBytes = snapshot.stat.availableBytes
                val usedBytes = totalBytes - availBytes
                storageUsedPercent = usedBytes.toFloat() / totalBytes.toFloat()
                storageUsedGb = usedBytes / (1024.0 * 1024.0 * 1024.0)
                storageTotalGb = totalBytes / (1024.0 * 1024.0 * 1024.0)

                if (snapshot.battPct != null) batteryPercent = snapshot.battPct
                if (snapshot.charging != null) isCharging = snapshot.charging

                ramHistory.add(ramUsedPercent)
                if (ramHistory.size > 40) ramHistory.removeAt(0)

                cpuCoreInfo = snapshot.freqs
                cpuReadBlocked = snapshot.freqs.all { it.currentMhz == null }
                loadAvg = snapshot.loadAvg

                // CPU % tổng thể
                val currCpuSnap = snapshot.cpuSnap
                if (prevCpuSnap != null && currCpuSnap != null) {
                    val pct = calcCpuUsagePercent(prevCpuSnap, currCpuSnap)
                    if (pct != null) {
                        cpuUsagePercent = pct
                        cpuUsageHistory.add(pct)
                        if (cpuUsageHistory.size > 40) cpuUsageHistory.removeAt(0)
                        cpuUsageBlocked = false
                        cpuUsageEstimated = false
                    } else {
                        // Fallback: ước tính từ tần số nhân (cách CPU-Z / CPU Stats dùng khi /proc/stat bị chặn)
                        val est = estimateCpuUsageFromFreq(snapshot.freqs)
                        if (est != null) {
                            cpuUsagePercent = est
                            cpuUsageHistory.add(est)
                            if (cpuUsageHistory.size > 40) cpuUsageHistory.removeAt(0)
                            cpuUsageBlocked = false
                            cpuUsageEstimated = true
                        } else {
                            cpuUsageBlocked = true
                            cpuUsageEstimated = false
                        }
                    }
                } else {
                    // Không đọc được /proc/stat → dùng ước tính tần số
                    val est = estimateCpuUsageFromFreq(snapshot.freqs)
                    if (est != null) {
                        cpuUsagePercent = est
                        cpuUsageHistory.add(est)
                        if (cpuUsageHistory.size > 40) cpuUsageHistory.removeAt(0)
                        cpuUsageBlocked = false
                        cpuUsageEstimated = true
                    } else {
                        cpuUsageBlocked = true
                        cpuUsageEstimated = false
                    }
                }
                prevCpuSnap = currCpuSnap

                // Tốc độ mạng
                val currNetSnap = snapshot.netSnap
                val (down, up) = calcNetworkSpeedKBs(prevNetSnap, currNetSnap)
                if (down < 0) {
                    networkUnsupported = true
                } else {
                    downloadKBs = down
                    uploadKBs = up
                    downloadHistory.add((down / 512.0).coerceIn(0.0, 1.0).toFloat()) // chuẩn hoá thô cho đồ thị
                    if (downloadHistory.size > 40) downloadHistory.removeAt(0)
                }
                prevNetSnap = currNetSnap

                // Tốc độ đĩa
                val currDiskSnap = snapshot.diskSnap
                if (prevDiskSnap != null && currDiskSnap != null) {
                    val (r, w) = calcDiskSpeedKBs(prevDiskSnap, currDiskSnap)
                    diskReadKBs = r
                    diskWriteKBs = w
                    diskReadBlocked = false
                } else {
                    diskReadBlocked = true
                }
                prevDiskSnap = currDiskSnap
            } catch (e: Exception) {
                // Bỏ qua lỗi đọc dữ liệu ở lần lặp này, không để crash cả app
                logCaughtError(context, "PerformanceScreen.loop", e)
            }

            delay(1000)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        item {
            PerfCard(
                title = "CPU",
                subtitle = when {
                    cpuUsageBlocked -> "$cpuCores nhân"
                    cpuUsageEstimated -> "≈${(cpuUsagePercent * 100).toInt()}% · $cpuCores nhân"
                    else -> "${(cpuUsagePercent * 100).toInt()}% · $cpuCores nhân"
                },
                percent = if (cpuUsageBlocked) null else cpuUsagePercent,
                graphValues = if (cpuUsageBlocked) null else cpuUsageHistory,
                icon = Icons.Default.Memory,
                accentColor = PerfCpuBlue
            ) {
                Text(
                    "Chip: ${cpuHardware.hardware ?: "Không xác định"}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Text(
                    "Board: ${cpuHardware.processor ?: "N/A"}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Text(
                    "Kiến trúc: ${cpuHardware.abi}",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                if (cpuUsageEstimated && !cpuUsageBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "≈ Ước tính từ tần số nhân (máy chặn /proc/stat). Số liệu thật từ sysfs.",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                }

                if (cpuUsageBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Không đọc được %CPU tổng (máy chặn /proc/stat) và cũng không đọc được tần số nhân.",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                    if (loadAvg != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Tải hệ thống thật (kernel, /proc/loadavg): " +
                                    "${"%.2f".format(loadAvg!!.avg1min)} (1p) · " +
                                    "${"%.2f".format(loadAvg!!.avg5min)} (5p) · " +
                                    "${"%.2f".format(loadAvg!!.avg15min)} (15p)",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            "Số càng gần $cpuCores (số nhân CPU) là máy càng bận.",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                if (cpuReadBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Máy này chặn đọc tần số CPU chi tiết (giới hạn từ nhà sản xuất/Android 8+), " +
                                "giống nhiều app CPU-Z gặp trên một số dòng máy.",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                } else if (cpuCoreInfo.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Tần số từng nhân (real-time)",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    cpuCoreInfo.forEach { core -> CpuCoreBar(core) }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Bộ nhớ (RAM)",
                subtitle = "%.1f/%.1f GB (%d%%)".format(ramUsedGb, ramTotalGb, (ramUsedPercent * 100).toInt()),
                percent = ramUsedPercent,
                graphValues = ramHistory,
                icon = Icons.Default.Storage,
                accentColor = PerfRamPurple
            )
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Ổ đĩa (Storage)",
                subtitle = "%.1f/%.1f GB (%d%%)".format(storageUsedGb, storageTotalGb, (storageUsedPercent * 100).toInt()),
                percent = storageUsedPercent,
                graphValues = null,
                icon = Icons.Default.Save,
                accentColor = PerfDiskYellow
            ) {
                if (diskReadBlocked) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Máy này chặn đọc tốc độ đọc/ghi đĩa real-time (/proc/diskstats bị giới hạn từ Android 10+).",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("↓ Đọc: %.0f KB/s".format(diskReadKBs), color = TextSecondary, fontSize = 12.sp)
                        Text("↑ Ghi: %.0f KB/s".format(diskWriteKBs), color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Mạng (Network)",
                subtitle = if (networkUnsupported) "Không hỗ trợ" else "%.0f KB/s ↓".format(downloadKBs),
                percent = null,
                graphValues = if (networkUnsupported) null else downloadHistory,
                icon = Icons.Default.Wifi,
                accentColor = PerfNetworkGreen
            ) {
                if (networkUnsupported) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "⚠ Thiết bị không hỗ trợ TrafficStats.",
                        color = WarnOrange,
                        fontSize = 11.sp
                    )
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("↓ Tải xuống: %.0f KB/s".format(downloadKBs), color = TextSecondary, fontSize = 12.sp)
                        Text("↑ Tải lên: %.0f KB/s".format(uploadKBs), color = TextSecondary, fontSize = 12.sp)
                    }
                    Text(
                        "Tổng từ lúc bật máy — số liệu thật từ TrafficStats",
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
        item { Spacer(modifier = Modifier.height(10.dp)) }
        item {
            PerfCard(
                title = "Pin",
                subtitle = "$batteryPercent%" + if (isCharging) " (Đang sạc)" else "",
                percent = batteryPercent / 100f,
                graphValues = null,
                icon = Icons.Default.BatteryFull,
                accentColor = PerfBatteryTeal
            )
        }
        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
fun CpuCoreBar(core: CpuCoreInfo) {
    val cur = core.currentMhz
    val max = core.maxMhz ?: 3000
    val fraction = if (cur != null && max > 0) (cur.toFloat() / max.toFloat()).coerceIn(0f, 1f) else 0f

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "Nhân ${core.coreIndex}",
            color = TextSecondary,
            fontSize = 11.sp,
            modifier = Modifier.width(52.dp)
        )
        Box(
            modifier = Modifier
                .weight(1f)
                .height(14.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(BgDark)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction)
                    .background(
                        Brush.horizontalGradient(listOf(PerfCpuBlue.copy(alpha = 0.6f), PerfCpuBlue)),
                        RoundedCornerShape(4.dp)
                    )
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            if (cur != null) "$cur MHz" else "N/A",
            color = TextPrimary,
            fontSize = 11.sp,
            modifier = Modifier.width(72.dp),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

@Composable
fun PerfCard(
    title: String,
    subtitle: String,
    percent: Float?,
    graphValues: List<Float>?,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    accentColor: androidx.compose.ui.graphics.Color = AccentTeal,
    extraContent: (@Composable ColumnScope.() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(BgPanel, BgPanel.copy(alpha = 0.9f))),
                RoundedCornerShape(12.dp)
            )
            .border(1.dp, BorderColor, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
            Text(subtitle, color = accentColor, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(modifier = Modifier.height(10.dp))

        if (percent != null) {
            LinearProgressIndicator(
                progress = { percent },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = accentColor,
                trackColor = BgDark
            )
        }

        if (graphValues != null && graphValues.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(BgDark, RoundedCornerShape(8.dp))
            ) {
                val w = size.width
                val h = size.height

                // Lưới nền giống PC
                for (i in 1..3) {
                    val y = h * i / 4
                    drawLine(
                        color = BorderColor.copy(alpha = 0.6f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                if (graphValues.size > 1) {
                    val stepX = w / (40 - 1).coerceAtLeast(1)
                    val linePath = androidx.compose.ui.graphics.Path()
                    val fillPath = androidx.compose.ui.graphics.Path()

                    graphValues.forEachIndexed { index, value ->
                        val x = index * stepX
                        val y = h - (value * h)
                        if (index == 0) {
                            linePath.moveTo(x, y)
                            fillPath.moveTo(x, h)
                            fillPath.lineTo(x, y)
                        } else {
                            linePath.lineTo(x, y)
                            fillPath.lineTo(x, y)
                        }
                    }
                    val lastX = (graphValues.size - 1) * stepX
                    fillPath.lineTo(lastX, h)
                    fillPath.close()

                    // Vùng tô gradient mờ dần dưới đường line, giống Performance tab trên PC
                    drawPath(
                        fillPath,
                        brush = Brush.verticalGradient(
                            listOf(accentColor.copy(alpha = 0.35f), Color.Transparent)
                        )
                    )
                    drawPath(linePath, color = accentColor, style = Stroke(width = 3.5f))
                }
            }
        }

        extraContent?.let {
            Spacer(modifier = Modifier.height(8.dp))
            it()
        }
    }
}

// ---------------------------------------------------------------------------------
// TAB 3: STARTUP
// ---------------------------------------------------------------------------------

@Composable
fun StartupScreen() {
    val context = LocalContext.current
    var startupApps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        try {
            startupApps = withContext(Dispatchers.IO) { loadBootReceiverApps(context) }
        } catch (e: Exception) {
            logCaughtError(context, "StartupScreen.load", e)
            startupApps = emptyList()
        }
        loading = false
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgPanel)
                .padding(12.dp)
        ) {
            Text(
                "Các app dưới đây có thể tự khởi động cùng máy. Android không cho phép " +
                        "tắt/bật quyền này trực tiếp trong app — nhấn vào từng app để mở " +
                        "Cài đặt hệ thống và tắt thủ công.",
                color = TextSecondary,
                fontSize = 12.sp
            )
        }
        HorizontalDivider(color = BorderColor, thickness = 1.dp)

        if (loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = AccentTeal)
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(startupApps) { app ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                intent.data = Uri.parse("package:${app.packageName}")
                                context.startActivity(intent)
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val bitmap = remember(app.packageName) { app.icon.toBitmapSafe() }
                        if (bitmap != null) {
                            androidx.compose.foundation.Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(app.name, color = TextPrimary, fontSize = 14.sp)
                            Text(app.packageName, color = TextSecondary, fontSize = 11.sp)
                        }
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = TextSecondary
                        )
                    }
                    HorizontalDivider(color = BorderColor.copy(alpha = 0.4f), thickness = 0.5.dp)
                }
            }
        }
    }
}

fun loadBootReceiverApps(context: Context): List<AppEntry> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_BOOT_COMPLETED)
    val receivers = pm.queryBroadcastReceivers(intent, PackageManager.GET_META_DATA)
    val packageNames = receivers.map { it.activityInfo.packageName }.distinct()

    return packageNames.mapNotNull { pkgName ->
        try {
            val appInfo = pm.getApplicationInfo(pkgName, 0)
            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            if (isSystem) return@mapNotNull null
            AppEntry(
                name = pm.getApplicationLabel(appInfo).toString(),
                packageName = pkgName,
                icon = pm.getApplicationIcon(appInfo),
                sizeMb = 0.0,
                isSystemApp = isSystem
            )
        } catch (e: Exception) {
            null
        }
    }.sortedBy { it.name }
}

// ---------------------------------------------------------------------------------
// ĐỌC CPU THẬT TỪ SYSFS — cùng cách CPU-Z Mobile làm (không cần root)
// ---------------------------------------------------------------------------------

data class CpuCoreInfo(
    val coreIndex: Int,
    val currentMhz: Int?, // null nếu máy chặn đọc (một số hãng giới hạn từ Android 8+)
    val minMhz: Int?,
    val maxMhz: Int?
)

data class CpuHardwareInfo(
    val hardware: String?,   // dòng "Hardware" trong /proc/cpuinfo
    val processor: String?,  // dòng "model name" hoặc "Processor"
    val abi: String,
    val coreCount: Int
)

// Đọc 1 dòng số nguyên từ file sysfs, trả về null nếu không đọc được (bị chặn quyền)
private fun readSysfsInt(path: String): Int? {
    return try {
        File(path).readText().trim().toIntOrNull()
    } catch (e: Exception) {
        null // bị chặn bởi SELinux/nhà sản xuất, hoặc file không tồn tại
    }
}

fun readCpuCoreFrequencies(coreCount: Int): List<CpuCoreInfo> {
    return (0 until coreCount).map { i ->
        val base = "/sys/devices/system/cpu/cpu$i/cpufreq"
        val curKhz = readSysfsInt("$base/scaling_cur_freq")
        val minKhz = readSysfsInt("$base/cpuinfo_min_freq")
        val maxKhz = readSysfsInt("$base/cpuinfo_max_freq")
        CpuCoreInfo(
            coreIndex = i,
            currentMhz = curKhz?.let { it / 1000 },
            minMhz = minKhz?.let { it / 1000 },
            maxMhz = maxKhz?.let { it / 1000 }
        )
    }
}

fun readCpuHardwareInfo(): CpuHardwareInfo {
    var hardware: String? = null
    var processor: String? = null
    try {
        File("/proc/cpuinfo").forEachLine { line ->
            when {
                line.startsWith("Hardware") -> hardware = line.substringAfter(":").trim()
                line.startsWith("model name") -> processor = line.substringAfter(":").trim()
                line.startsWith("Processor") && processor == null -> processor = line.substringAfter(":").trim()
            }
        }
    } catch (e: Exception) {
        // Không đọc được /proc/cpuinfo, sẽ hiện Build.HARDWARE thay thế bên dưới
    }
    return CpuHardwareInfo(
        hardware = hardware ?: Build.HARDWARE,
        processor = processor ?: Build.BOARD,
        abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "N/A",
        coreCount = Runtime.getRuntime().availableProcessors()
    )
}

// ---------------------------------------------------------------------------------
// CPU % TỔNG THỂ — đọc /proc/stat, tính theo delta giữa 2 lần đọc (giống cách Task Manager
// thật tính %CPU: so sánh jiffies "busy" và "idle" giữa 2 thời điểm)
// ---------------------------------------------------------------------------------

data class CpuStatSnapshot(val idle: Long, val total: Long)

fun readCpuStatSnapshot(): CpuStatSnapshot? {
    return try {
        val line = File("/proc/stat").bufferedReader().readLine() ?: return null
        // Dòng đầu dạng: "cpu  12345 678 9012 34567 890 0 12 0 0 0"
        val parts = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
        if (parts.size < 4) return null
        val user = parts[0]; val nice = parts[1]; val system = parts[2]; val idle = parts[3]
        val iowait = parts.getOrElse(4) { 0L }
        val irq = parts.getOrElse(5) { 0L }
        val softirq = parts.getOrElse(6) { 0L }
        val steal = parts.getOrElse(7) { 0L }
        val idleAll = idle + iowait
        val total = user + nice + system + idleAll + irq + softirq + steal
        CpuStatSnapshot(idleAll, total)
    } catch (e: Exception) {
        null // Bị chặn quyền đọc /proc/stat (hiếm, nhưng vài máy hãng lạ có thể chặn)
    }
}

fun calcCpuUsagePercent(prev: CpuStatSnapshot, curr: CpuStatSnapshot): Float? {
    val totalDelta = curr.total - prev.total
    val idleDelta = curr.idle - prev.idle
    if (totalDelta <= 0) return null
    return ((totalDelta - idleDelta).toFloat() / totalDelta.toFloat()).coerceIn(0f, 1f)
}

/**
 * Ước tính %CPU tổng từ tần số hiện tại của từng nhân.
 * Công thức: trung bình (currentMhz / maxMhz) của các nhân đọc được.
 * Đây là proxy phổ biến khi /proc/stat bị SELinux chặn (Android 8+).
 * Không chính xác 100% như jiffies, nhưng là số liệu thật từ sysfs, cập nhật real-time.
 */
fun estimateCpuUsageFromFreq(cores: List<CpuCoreInfo>): Float? {
    val ratios = cores.mapNotNull { core ->
        val cur = core.currentMhz ?: return@mapNotNull null
        val max = core.maxMhz ?: return@mapNotNull null
        if (max <= 0) return@mapNotNull null
        (cur.toFloat() / max.toFloat()).coerceIn(0f, 1f)
    }
    if (ratios.isEmpty()) return null
    return ratios.average().toFloat()
}

// Số liệu tải hệ thống thật từ kernel (/proc/loadavg), thường KHÔNG bị Android chặn
// dù /proc/stat bị chặn. Đây là "load average" kiểu Linux/Unix, không phải %CPU tức thời,
// nhưng là con số thật do kernel tính, dùng để thay thế khi %CPU tổng bị khoá.
data class LoadAvg(val avg1min: Float, val avg5min: Float, val avg15min: Float)

fun readLoadAvg(): LoadAvg? {
    return try {
        val line = File("/proc/loadavg").bufferedReader().readLine() ?: return null
        val parts = line.trim().split(Regex("\\s+"))
        if (parts.size < 3) return null
        LoadAvg(
            parts[0].toFloatOrNull() ?: return null,
            parts[1].toFloatOrNull() ?: return null,
            parts[2].toFloatOrNull() ?: return null
        )
    } catch (e: Exception) {
        null // Vài máy hãng lạ (Samsung One UI, MIUI bản chặn cao) vẫn có thể khoá luôn file này
    }
}

// ---------------------------------------------------------------------------------
// TỐC ĐỘ MẠNG THẬT — TrafficStats, tính delta byte giữa các lần đọc mỗi giây
// ---------------------------------------------------------------------------------

data class NetworkSnapshot(val rxBytes: Long, val txBytes: Long, val timeMs: Long)

fun readNetworkSnapshot(): NetworkSnapshot {
    val rx = android.net.TrafficStats.getTotalRxBytes()
    val tx = android.net.TrafficStats.getTotalTxBytes()
    return NetworkSnapshot(rx, tx, System.currentTimeMillis())
}

// Trả về Pair(downloadKBs, uploadKBs). Nếu thiết bị không hỗ trợ TrafficStats trả về -1 cho cả 2.
fun calcNetworkSpeedKBs(prev: NetworkSnapshot, curr: NetworkSnapshot): Pair<Double, Double> {
    if (prev.rxBytes == android.net.TrafficStats.UNSUPPORTED.toLong() ||
        curr.rxBytes == android.net.TrafficStats.UNSUPPORTED.toLong()
    ) return -1.0 to -1.0
    val dtSec = ((curr.timeMs - prev.timeMs).coerceAtLeast(1)) / 1000.0
    val downKBs = ((curr.rxBytes - prev.rxBytes).coerceAtLeast(0)) / 1024.0 / dtSec
    val upKBs = ((curr.txBytes - prev.txBytes).coerceAtLeast(0)) / 1024.0 / dtSec
    return downKBs to upKBs
}

// ---------------------------------------------------------------------------------
// TỐC ĐỘ ĐĨA THẬT — đọc /proc/diskstats, cộng dồn số sector đọc/ghi của các block device
// chính (mmcblk, sda, dm-*), quy đổi ra KB/s theo delta mỗi giây
// ---------------------------------------------------------------------------------

data class DiskSnapshot(val readSectors: Long, val writeSectors: Long, val timeMs: Long)

fun readDiskSnapshot(): DiskSnapshot? {
    return try {
        var readSectors = 0L
        var writeSectors = 0L
        File("/proc/diskstats").forEachLine { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 10) return@forEachLine
            val deviceName = parts[2]
            // Chỉ tính thiết bị lưu trữ chính, bỏ qua các phân vùng loop/ram
            if (deviceName.startsWith("mmcblk0") && !deviceName.contains("p") ||
                deviceName.startsWith("sda") && deviceName.length <= 4 ||
                deviceName.startsWith("dm-")
            ) {
                readSectors += parts[5].toLongOrNull() ?: 0L
                writeSectors += parts[9].toLongOrNull() ?: 0L
            }
        }
        DiskSnapshot(readSectors, writeSectors, System.currentTimeMillis())
    } catch (e: Exception) {
        null // Nhiều máy Android 10+ chặn đọc /proc/diskstats vì lý do bảo mật (SELinux)
    }
}

// Sector chuẩn Linux = 512 byte. Trả về Pair(readKBs, writeKBs)
fun calcDiskSpeedKBs(prev: DiskSnapshot, curr: DiskSnapshot): Pair<Double, Double> {
    val dtSec = ((curr.timeMs - prev.timeMs).coerceAtLeast(1)) / 1000.0
    val readKBs = ((curr.readSectors - prev.readSectors).coerceAtLeast(0)) * 512.0 / 1024.0 / dtSec
    val writeKBs = ((curr.writeSectors - prev.writeSectors).coerceAtLeast(0)) * 512.0 / 1024.0 / dtSec
    return readKBs to writeKBs
}
